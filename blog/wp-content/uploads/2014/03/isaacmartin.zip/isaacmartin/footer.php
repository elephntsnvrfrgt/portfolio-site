<div class="clear"></div>
</div>
<footer id="footer" role="contentinfo">

	<p class="copyright">
		the work of isaac martin. ©2014
	</p>
	<p class="social">
		<a href="http://www.linkedin.com/in/immartin/" target="_blank"><span class="icon-linkedin"></span></a>
		<a href="https://www.twitter.com/isaacmart_in" target="_blank"><span class="icon-twitter"></span></a>
		<a href="http://www.be.net/isaacmartin" target="_blank"><span class="icon-behance"></span></a>
	</p>

</footer>
</div>

	<script src="js/modernizr.js"></script>
	<script src="js/jquery-2.1.0.min.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">

		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-47998323-1']);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();

	</script>

<?php wp_footer(); ?>
</body>
</html>